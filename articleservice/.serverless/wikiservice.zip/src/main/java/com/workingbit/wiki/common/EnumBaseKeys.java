package com.workingbit.wiki.common;

/**
 * Created by Aleksey Popryaduhin on 19:05 09/08/2017.
 */
public enum EnumBaseKeys {
  id
}
