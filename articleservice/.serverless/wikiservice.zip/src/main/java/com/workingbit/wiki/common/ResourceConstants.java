package com.workingbit.wiki.common;

/**
 * Created by Aleksey Popryaduhin on 13:24 09/08/2017.
 */
public class ResourceConstants {
  public static final String ARTICLE = "/article";
}
