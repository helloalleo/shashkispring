package com.workingbit.wiki.common;

/**
 * Created by Aleksey Popryaduhin on 20:47 09/08/2017.
 */
public enum EnumArticleKeys {

  Published, NewAdded, Banned
}
